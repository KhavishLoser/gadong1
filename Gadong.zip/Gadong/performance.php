<?php include 'includes/header.php'?>
<?php include 'includes/navbar.php'?>
           <?php include 'includes/sidebar.php'?>
            <div id="layoutSidenav_content">
                <main>  
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Performance Management</h1>
                        <span>________________________________________________________________________________________________________________________________________________________</span>
                <h2>ADD CONTENT HERE!!</h2>
                    </div>
</main>
                    
                       
     <?php include 'includes/script.php'?>
     <?php include 'includes/footer.php'?>