<?php
$host = 'localhost';
$dbname = 'gadong';
$user = 'hr2_Mamaa';
$pass = 'Human_Resource';

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>